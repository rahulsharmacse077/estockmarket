export class Company{
    companyCode:string;
    companyName:string;
    companyCeo:string;
    companyTurnover:number;
    companyWebsite:string;
    companyListedIn:string;   
}