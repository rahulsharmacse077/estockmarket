export class StockPrice{
    companyCode:string;
    stockPriceValue:number;
    stockDate:string;
    startDate:Date;
    startEnd:Date;
}