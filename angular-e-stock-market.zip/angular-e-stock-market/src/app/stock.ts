export class Stock{
    stockPriceList:any;
    min:number;
    max:number;
    average:number;
}